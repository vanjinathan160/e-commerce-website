import { Product, Review } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Samsung Galaxy S24 Ultra 5G (Titanium Gray, 256GB)',
    price: 124999,
    originalPrice: 134999,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
      'https://images.pexels.com/photos/1275229/pexels-photo-1275229.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.4,
    reviewCount: 2849,
    category: 'mobiles',
    brand: 'Samsung',
    description: 'Experience the ultimate smartphone with Galaxy AI, 200MP camera, S Pen, and titanium build quality.',
    features: ['Snapdragon 8 Gen 3', '200MP Quad Camera', 'S Pen included', '6.8" Dynamic AMOLED 2X', '5000mAh Battery'],
    inStock: true,
    freeShipping: true,
    primeEligible: true,
    lightningDeal: true,
    dealPrice: 119999
  },
  {
    id: '2',
    name: 'LG 55" 4K Ultra HD Smart LED TV (55UP7500PTZ)',
    price: 54990,
    originalPrice: 69990,
    image: 'https://images.pexels.com/photos/1201996/pexels-photo-1201996.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/1201996/pexels-photo-1201996.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.2,
    reviewCount: 1892,
    category: 'electronics',
    brand: 'LG',
    description: 'Immerse yourself in stunning 4K clarity with webOS smart platform and HDR10 support.',
    features: ['4K UHD Resolution', 'webOS Smart TV', 'HDR10 & HLG', 'AI ThinQ', 'Magic Remote'],
    inStock: true,
    freeShipping: true,
    primeEligible: true
  },
  {
    id: '3',
    name: 'Nike Air Force 1 \'07 White Sneakers',
    price: 7495,
    originalPrice: 8995,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.6,
    reviewCount: 3156,
    category: 'fashion',
    brand: 'Nike',
    description: 'Classic basketball-inspired sneakers with premium leather upper and Air-Sole unit.',
    features: ['Premium leather upper', 'Air-Sole unit cushioning', 'Rubber outsole', 'Classic design'],
    inStock: true,
    freeShipping: true,
    primeEligible: true
  },
  {
    id: '4',
    name: 'Sony WH-CH720N Wireless Noise Canceling Headphones',
    price: 8990,
    originalPrice: 12990,
    image: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.3,
    reviewCount: 1567,
    category: 'electronics',
    brand: 'Sony',
    description: 'Premium wireless headphones with industry-leading noise cancellation and 35-hour battery life.',
    features: ['Active Noise Cancellation', '35-hour battery life', 'Quick Charge', 'Multipoint connection'],
    inStock: true,
    freeShipping: true,
    primeEligible: false,
    lightningDeal: true,
    dealPrice: 7990
  },
  {
    id: '5',
    name: 'Levi\'s Men\'s Regular Fit Jeans (Blue)',
    price: 2499,
    originalPrice: 3499,
    image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.1,
    reviewCount: 924,
    category: 'fashion',
    brand: 'Levi\'s',
    description: 'Classic regular fit jeans crafted from premium denim with authentic Levi\'s styling.',
    features: ['100% Cotton Denim', 'Regular Fit', '5-pocket styling', 'Button fly'],
    inStock: true,
    freeShipping: false,
    primeEligible: true
  },
  {
    id: '6',
    name: 'Philips Air Fryer HD9252/90 (4.1L, Black)',
    price: 12995,
    originalPrice: 16995,
    image: 'https://images.pexels.com/photos/6933849/pexels-photo-6933849.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/6933849/pexels-photo-6933849.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.5,
    reviewCount: 2890,
    category: 'home',
    brand: 'Philips',
    description: 'Cook healthier meals with up to 90% less fat using Rapid Air technology.',
    features: ['4.1L capacity', 'Rapid Air Technology', 'Digital display', 'Dishwasher safe parts'],
    inStock: true,
    freeShipping: true,
    primeEligible: true
  },
  {
    id: '7',
    name: 'Tata Tea Premium (1kg Pack)',
    price: 485,
    originalPrice: 520,
    image: 'https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.3,
    reviewCount: 5670,
    category: 'grocery',
    brand: 'Tata Tea',
    description: 'Premium quality tea blend with rich aroma and authentic taste.',
    features: ['1kg pack', 'Premium blend', 'Rich aroma', 'Fresh packaging'],
    inStock: true,
    freeShipping: false,
    primeEligible: true
  },
  {
    id: '8',
    name: 'Lakme Absolute Perfect Radiance Skin Lightening Facewash',
    price: 175,
    originalPrice: 200,
    image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&w=400',
    images: [
      'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&w=400'
    ],
    rating: 4.0,
    reviewCount: 1234,
    category: 'beauty',
    brand: 'Lakme',
    description: 'Gentle face wash with skin lightening properties for radiant and glowing skin.',
    features: ['Skin lightening', 'Gentle formula', '100ml tube', 'Suitable for all skin types'],
    inStock: true,
    freeShipping: false,
    primeEligible: true
  }
];

export const reviews: Review[] = [
  {
    id: '1',
    productId: '1',
    userName: 'Rajesh Kumar',
    rating: 5,
    title: 'Excellent phone with amazing camera!',
    content: 'The camera quality is outstanding and the S Pen functionality is very useful for work. Battery lasts the whole day easily.',
    date: '2024-01-15',
    verified: true
  },
  {
    id: '2',
    productId: '1',
    userName: 'Priya Sharma',
    rating: 4,
    title: 'Great upgrade from my old phone',
    content: 'Smooth performance and beautiful display. The titanium build feels premium. Worth the price.',
    date: '2024-01-10',
    verified: true
  },
  {
    id: '3',
    productId: '3',
    userName: 'Amit Singh',
    rating: 5,
    title: 'Perfect fit and very comfortable',
    content: 'These shoes are incredibly comfortable for daily wear and look great with any outfit.',
    date: '2024-01-08',
    verified: true
  },
  {
    id: '4',
    productId: '6',
    userName: 'Sunita Patel',
    rating: 5,
    title: 'Best kitchen appliance purchase!',
    content: 'Makes cooking so much easier and healthier. The food tastes great and cooks evenly.',
    date: '2024-01-12',
    verified: true
  }
];