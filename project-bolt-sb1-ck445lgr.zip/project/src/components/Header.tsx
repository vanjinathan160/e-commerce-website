import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, X } from 'lucide-react';
import { CartItem, User as UserType } from '../types';

interface HeaderProps {
  cartItems: CartItem[];
  user: UserType | null;
  onCartClick: () => void;
  onAuthClick: () => void;
  onSearch: (query: string) => void;
  onCategorySelect: (category: string) => void;
  onHomeClick: () => void;
}

export default function Header({ 
  cartItems, 
  user, 
  onCartClick, 
  onAuthClick, 
  onSearch, 
  onCategorySelect,
  onHomeClick 
}: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  const categories = [
    'Electronics', 'Fashion', 'Home & Kitchen', 'Grocery', 'Mobiles & Tablets', 'Beauty & Personal Care', 'Sports & Fitness', 'Books & Media'
  ];

  return (
    <header className="bg-gray-900 text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={onHomeClick}
            className="flex items-center space-x-2 hover:text-orange-400 transition-colors"
          >
            <div className="bg-orange-500 p-2 rounded">
              <ShoppingCart className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold">ShopHub</span>
          </button>

          {/* Search Bar */}
          <form onSubmit={handleSearchSubmit} className="flex-1 max-w-2xl mx-8 hidden md:block">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full pl-4 pr-12 py-2 bg-white text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-orange-500 hover:bg-orange-600 p-1 rounded transition-colors"
              >
                <Search className="w-4 h-4 text-white" />
              </button>
            </div>
          </form>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* User */}
            <button
              onClick={onAuthClick}
              className="flex items-center space-x-1 hover:text-orange-400 transition-colors"
            >
              <User className="w-5 h-5" />
              <span className="hidden sm:inline">
                {user ? user.name : 'Sign In'}
              </span>
            </button>

            {/* Cart */}
            <button
              onClick={onCartClick}
              className="flex items-center space-x-1 hover:text-orange-400 transition-colors relative"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
              <span className="hidden sm:inline">Cart</span>
            </button>

            {/* Mobile Menu */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden pb-4">
          <form onSubmit={handleSearchSubmit}>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full pl-4 pr-12 py-2 bg-white text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-orange-500 hover:bg-orange-600 p-1 rounded transition-colors"
              >
                <Search className="w-4 h-4 text-white" />
              </button>
            </div>
          </form>
        </div>

        {/* Categories */}
        <div className="hidden md:flex items-center space-x-6 py-2 border-t border-gray-700">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => onCategorySelect(category.toLowerCase().replace(/\s+/g, ''))}
              className="text-sm hover:text-orange-400 transition-colors"
            >
              {category}
            </button>
          ))}
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-700 py-4">
            <div className="flex flex-col space-y-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => {
                    onCategorySelect(category.toLowerCase().replace(/\s+/g, ''));
                    setIsMenuOpen(false);
                  }}
                  className="text-left py-2 hover:text-orange-400 transition-colors"
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}