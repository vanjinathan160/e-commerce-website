import React from 'react';
import { Clock, Zap } from 'lucide-react';
import { products } from '../data/products';
import { Product } from '../types';

interface LightningDealsProps {
  onAddToCart: (product: Product) => void;
  onProductClick: (product: Product) => void;
}

export default function LightningDeals({ onAddToCart, onProductClick }: LightningDealsProps) {
  const lightningDeals = products.filter(product => product.lightningDeal);

  if (lightningDeals.length === 0) return null;

  return (
    <section className="py-12 bg-gradient-to-r from-yellow-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="bg-yellow-500 p-2 rounded-full">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Lightning Deals</h2>
              <p className="text-gray-600">Limited time offers - Grab them fast!</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-red-600">
            <Clock className="w-5 h-5" />
            <span className="font-semibold">Ends in 2h 45m</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {lightningDeals.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow group border-2 border-yellow-200">
              <div className="relative">
                <button
                  onClick={() => onProductClick(product)}
                  className="w-full aspect-square overflow-hidden rounded-t-lg"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </button>
                <div className="absolute top-2 left-2 bg-yellow-500 text-black px-2 py-1 rounded text-xs font-semibold animate-pulse">
                  ⚡ Lightning Deal
                </div>
                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-semibold">
                  {Math.round(((product.originalPrice || product.price) - (product.dealPrice || product.price)) / (product.originalPrice || product.price) * 100)}% OFF
                </div>
              </div>
              
              <div className="p-4">
                <button
                  onClick={() => onProductClick(product)}
                  className="text-left w-full"
                >
                  <h3 className="font-semibold text-gray-900 mb-2 hover:text-orange-600 transition-colors line-clamp-2">
                    {product.name}
                  </h3>
                </button>
                
                <div className="flex items-center space-x-2 mb-3">
                  <span className="text-2xl font-bold text-red-600">
                    ₹{(product.dealPrice || product.price).toLocaleString('en-IN')}
                  </span>
                  <span className="text-sm text-gray-500 line-through">
                    ₹{(product.originalPrice || product.price).toLocaleString('en-IN')}
                  </span>
                </div>
                
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-600 mb-1">
                    <span>Claimed</span>
                    <span>67%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-red-500 h-2 rounded-full" style={{ width: '67%' }}></div>
                  </div>
                </div>
                
                <button
                  onClick={() => onAddToCart(product)}
                  className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white py-2 rounded-lg font-semibold transition-colors"
                >
                  Grab Deal Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}