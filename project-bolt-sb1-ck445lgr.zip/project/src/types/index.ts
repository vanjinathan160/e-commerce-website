export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  rating: number;
  reviewCount: number;
  category: string;
  brand: string;
  description: string;
  features: string[];
  inStock: boolean;
  freeShipping: boolean;
  primeEligible: boolean;
  lightningDeal?: boolean;
  dealPrice?: number;
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  title: string;
  content: string;
  date: string;
  verified: boolean;
}

export interface Category {
  id: string;
  name: string;
  image: string;
  productCount: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface FilterState {
  category: string;
  priceRange: [number, number];
  minRating: number;
  brand: string;
  inStock: boolean;
  freeShipping: boolean;
  primeEligible: boolean;
}